//L1F18BSCS0427
//Hammad
#pragma once
#include <iostream>
using namespace std;

template<typename T>
struct Node 
{
    T Data;
    int colour;
    Node<T>* Parent;
    Node<T>* Left;
    Node<T>* Right;
};


template<typename T>
class RedandBlackTree 
{
private:
    Node<T>* ParentRB;
    Node<T>* RootRB;

    void INORDERLNR(Node<T>* root)
    {
        if (root != ParentRB)
        {
            INORDERLNR(root->Left);
            string c = root->colour ? " Red " : " Black ";
            cout << root->Data << " {";
            cout << c;
            cout << "} ";
            cout << endl;
            INORDERLNR(root->Right);
        }
    }
    Node<T>* left(Node<T>* root)
    {
        while (root->Left != ParentRB)
            root = root->Left;

        return root;
    }
    void INORDERRNL(Node<T>* root)
    {
        if (root != ParentRB)
        {
            INORDERRNL(root->Right);
            string c = root->colour ? " Red " : " Black ";
            cout << root->Data << " {";
            cout << c;
            cout << "} ";
            cout << endl;
            INORDERRNL(root->Left);
        }
    }


    void POSTORDERLRN(Node<T>* root)
    {
        if (root != ParentRB)
        {
            POSTORDERLRN(root->Left);
            POSTORDERLRN(root->Right);
            string c = root->colour ? " Red " : " Black ";
            cout << root->Data << " {";
            cout << c;
            cout << "} ";
            cout << endl;
        }
    }


    void POSTORDERRLN(Node<T>* root)
    {
        if (root != ParentRB)
        {
            POSTORDERRLN(root->Right);
            POSTORDERRLN(root->Left);
            string c = root->colour ? " Red " : " Black ";
            cout << root->Data << " {";
            cout << c;
            cout << "} ";
            cout << endl;
        }
    }

    T SEARCHVALUE(Node<T>* root, T Vs)
    {
        if (root == ParentRB || Vs == root->Data)
            return root->Data;
        if (Vs > root->Data)
            return SEARCHVALUE(root->Right, Vs);
        return SEARCHVALUE(root->Left, Vs);
    }

    void PREORDERNLR(Node<T>* root)
    {
        if (root != ParentRB)
        {
            string c = root->colour ? " Red " : " Black ";
            cout << root->Data << " {";
            cout << c;
            cout << "} ";
            cout << endl;
            PREORDERNLR(root->Left);
            PREORDERNLR(root->Right);
        }
    }

    void PREORDERNRL(Node<T>* root)
    {
        if (root != ParentRB)
        {
            string c = root->colour ? " Red " : " Black ";
            cout << root->Data << " {";
            cout << c;
            cout << "} ";
            cout << endl;
            PREORDERNRL(root->Right);
            PREORDERNRL(root->Left);
        }
    }

    void CHANGE(Node<T>* ptr, Node<T>* ptr2)
    {
        if (ptr->Parent == nullptr)
            RootRB = ptr2;
        else if (ptr == ptr->Parent->Right)
            ptr->Parent->Right = ptr2;
        else
            ptr->Parent->Left = ptr2;

        ptr2->Parent = ptr->Parent;
    }

    Node<T>* GetParent()
    {
        if (ParentRB == nullptr)
            cout << "parent is null ";
        cout << endl;

        return ParentRB;
    }
    void RotateRightSide(Node<T>* root)
    {

        Node<T>* ptr = root->Left;
        root->Left = ptr->Right;

        if (ptr->Right != ParentRB)
            ptr->Right->Parent = root;

        ptr->Parent = root->Parent;

        if (root->Parent == nullptr)
            RootRB = ptr;

        else if (root == root->Parent->Left)
            root->Parent->Left = ptr;

        else
            root->Parent->Right = ptr;

        ptr->Right = root;

        root->Parent = ptr;
    }
    
    bool DELETE(Node<T>* root, T Vs)
    {
        Node<T>* ptr2;
        int C;
        Node<T>* ptr3;
        Node<T>* Ptr = ParentRB;

        while (root != ParentRB)
        {
            if (root->Data == Vs)
                Ptr = root;
            if (root->Data > Vs)
                root = root->Left;
            else
                root = root->Right;
        }
        if (Ptr == ParentRB)
            return false;

        ptr3 = Ptr;
        C = ptr3->colour;

        if (Ptr->Right == ParentRB)
        {
            ptr2 = Ptr->Left;
            CHANGE(Ptr, ptr2);
        }
       
        else if (Ptr->Left == ParentRB)
        {
            ptr2 = Ptr->Right;
            CHANGE(Ptr, ptr2);
        }

        else
        {
            ptr3 = left(Ptr->Right);

            C = ptr3->colour;
            
            ptr2 = ptr3->Right;

            if (ptr3->Parent == Ptr)
                ptr2->Parent = ptr3;

            else
            {
                CHANGE(ptr3, ptr3->Right);
                
                ptr3->Right = Ptr->Right;
                
                ptr3->Right->Parent = ptr3;
            }

            CHANGE(Ptr, ptr3);

            ptr3->Left = Ptr->Left;
            ptr3->colour = Ptr->colour;
            ptr3->Left->Parent = ptr3;
           
        }

        delete Ptr;

        if (C == 0)
            DEL(ptr2);

        return true;
    }

    bool DUPLICATE(Node<T>* root, T Vs)
    {
        Node<T>* ptr2;
        int C;
        Node<T>* ptr3;

        Node<T>* Ptr = ParentRB;
        while (root != ParentRB)
        {
            if (root->Data == Vs)
                Ptr = root;
            if (root->Data > Vs)
                root = root->Left;
            else
                root = root->Right;
        }
        if (Ptr == ParentRB)
            return false;

        ptr3 = Ptr;
        C = ptr3->colour;

        if (Ptr->Right == ParentRB)
        {
            ptr2 = Ptr->Left;
            CHANGE(Ptr, ptr2);
        }

        else if (Ptr->Left == ParentRB)
        {
            ptr2 = Ptr->Right;
            CHANGE(Ptr, ptr2);
        }

        else
        {
            ptr3 = left(Ptr->Right);

            C = ptr3->colour;

            ptr2 = ptr3->Right;

            if (ptr3->Parent == Ptr)
                ptr2->Parent = ptr3;

            else
            {
                CHANGE(ptr3, ptr3->Right);

                ptr3->Right = Ptr->Right;

                ptr3->Right->Parent = ptr3;
            }

            CHANGE(Ptr, ptr3);

            ptr3->Left = Ptr->Left;
            ptr3->Left->Parent = ptr3;
            ptr3->colour = Ptr->colour;
        }

        delete Ptr;

        if (C == 0)
            DEL(ptr2);

        DUPLICATE(RootRB, Vs);

        return true;
        
    }

    T MAXVALUE(Node<T>* root)
    {
        while (root->Right != ParentRB)
            root = root->Right;

        return root->Data;
    }
  
    void DEL(Node<T>* root)
    {
        Node<T>* ptr;
        while (root != RootRB && root->colour == 0)
        {
            if (root = root->Parent->Right)
            {
                ptr = root->Parent->Left;
                if (ptr->colour == 1)
                {
                    ptr->colour = 0;

                    root->Parent->colour = 1;

                    RotateRightSide(root->Parent);

                    ptr = root->Parent->Left;
                }

                if (ptr->Right->colour == 0 && ptr->Left->colour == 0)
                {
                    ptr->colour = 1;
                    root = root->Parent;
                }
                else
                {
                    if (ptr->Left->colour == 0)
                    {
                        ptr->Right->colour = 0;
                        ptr->colour = 1;

                        RotateLeftSide(ptr);
                        ptr = root->Parent->Left;
                    }

                    ptr->colour = root->Parent->colour;
                    root->Parent->colour = 0;

                    ptr->Left->colour = 0;

                    RotateRightSide(root->Parent);

                    root = RootRB;
                }
            }
            else
            {
                ptr = root->Parent->Right;

                if (ptr->colour == 1)
                {
                    ptr->colour = 0;
                    root->Parent->colour = 1;

                    RotateLeftSide(root->Parent);
                    ptr = root->Parent->Right;
                }

                if (ptr->Left->colour == 0 && ptr->Right->colour == 0)
                {
                    ptr->colour = 1;
                    root = root->Parent;
                }
                else
                {
                    if (ptr->Right->colour == 0)
                    {
                        ptr->Left->colour = 0;
                        ptr->colour = 1;

                        RotateRightSide(ptr);

                        ptr = root->Parent->Right;
                    }

                    ptr->colour = root->Parent->colour;
                    root->Parent->colour = 0;

                    ptr->Right->colour = 0;

                    RotateLeftSide(root->Parent);

                    root = RootRB;
                }
            }
        }
        root->colour = 0;
    }
    void RotateLeftSide(Node<T>* root)
    {
        Node<T>* ptr = root->Right;
        root->Right = ptr->Left;

        if (ptr->Left != ParentRB)
            ptr->Left->Parent = root;

        ptr->Parent = root->Parent;

        if (root->Parent == nullptr)
            this->RootRB = ptr;

        else if (root == root->Parent->Left)
            root->Parent->Left = ptr;

        else
            root->Parent->Right = ptr;

        ptr->Left = root;
        root->Parent = ptr;
    }
    T MINVALUE(Node<T>* root)
    {
        while (root->Left != ParentRB)
            root = root->Left;

        return root->Data;
    }
    
    void INSERT(Node<T>* root)
    {
        Node<T>* ptr;
        while (root->Parent->colour == 1)
        {
            if (root->Parent == root->Parent->Parent->Left)
            {
                ptr = root->Parent->Parent->Right;

                if (ptr->colour == 1)
                {
                    ptr->colour = 0;
                    root->Parent->colour = 0;
                    root->Parent->Parent->colour = 1;
                    root = root->Parent->Parent;
                }
                else
                {
                    if (root == root->Parent->Right)
                    {
                        root = root->Parent;
                        RotateLeftSide(root);
                    }
                    root->Parent->colour = 0;

                    root->Parent->Parent->colour = 1;

                    RotateRightSide(root->Parent->Parent);
                }
            }
            else
            {
                ptr = root->Parent->Parent->Left;
                if (ptr->colour == 1)
                {
                    ptr->colour = 0;
                    root->Parent->colour = 0;
                    root->Parent->Parent->colour = 1;
                    root = root->Parent->Parent;
                }
                else
                {
                    if (root == root->Parent->Left)
                    {
                        root = root->Parent;
                        RotateRightSide(root);
                    }
                    root->Parent->colour = 0;
                    root->Parent->Parent->colour = 1;
                    RotateLeftSide(root->Parent->Parent);
                }
            }
            if (root == RootRB)
                break;
        }
        RootRB->colour = 0;
    }
    void Copy_Tree(Node<T>*& B1, const Node<T>* B2)
    {
        if (B2 == nullptr)
        {
            B1 = nullptr;
        }
        else
        {
            B1 = new Node<T>;
            B1->Parent = B2->Parent;
            B1->Data = B2->Data;
            B1->colour = B2->colour;
            Copy_Tree(B1->Left, B2->Left);
            Copy_Tree(B1->Right, B2->Right);
        }
    }

public:
    RedandBlackTree()
    {
        RootRB = new Node<T>;
        RootRB->Right = nullptr;
        RootRB->Left = nullptr;
        RootRB->colour = 0;
        ParentRB = RootRB;
    }
   
    RedandBlackTree(const RedandBlackTree<int>& RBT)
    {
        createcopy(RBT);
    }
   
   
    void createcopy( const RedandBlackTree<int>& B1)
    {
        Copy_Tree(this->RootRB, B1.RootRB);
        Copy_Tree(this->ParentRB, B1.ParentRB);
    }
    void InOrderLNR()
    {
        if (RootRB == nullptr)
            cout << "Tree is empty ";
        INORDERLNR(RootRB);
    }
    void InOrderRNL()
    {
        if (RootRB == nullptr)
            cout << "Tree is empty ";
        INORDERRNL(RootRB);
    }

    void PostOrderLRN()
    {
        if (RootRB == nullptr)
            cout << "Tree is empty ";
        POSTORDERLRN(RootRB);
    }
    void PostOrderRLN()
    {
        if (RootRB == nullptr)
            cout << "Tree is empty ";
        POSTORDERRLN(RootRB);
    }
    void PreOrderNLR()
    {
        if (RootRB == nullptr)
            cout << "Tree is empty ";
        PREORDERNLR(RootRB);
    }
    void DeleteANode(T Vs)
    {

        if (RootRB == nullptr)
            cout << "Tree is empty ";

        if (DELETE(RootRB, Vs) == true)
            cout << "\t" << " Value has been deleted from tree ";
        else
            cout << "Value not found ";

        cout << endl;
    }
    void PreOrderNRL()
    {
        if (RootRB == nullptr)
            cout << "Tree is empty ";
        PREORDERNRL(RootRB);
    }

    bool SearchvalueBool(T Vs)
    {
        if (SEARCHVALUE(RootRB, Vs) == Vs)
            return true;
        else
            return false;
    }
  

    void insert(T Vs)
    {
        Node<T>* ptr = nullptr;
        Node<T>* ptr2 = this->RootRB;

        Node<T>* root = new Node<T>;
        root->Parent = nullptr;
        root->Data = Vs;
        root->colour = 1;
        root->Left = ParentRB;
        root->Right = ParentRB;

        while (ptr2 != ParentRB)
        {
            ptr = ptr2;
            if (root->Data > ptr2->Data)
                ptr2 = ptr2->Right;

            else
                ptr2 = ptr2->Left;
        }

        root->Parent = ptr;
        if (ptr == nullptr)
            RootRB = root;

        else if (root->Data > ptr->Data)
            ptr->Right = root;

        else
            ptr->Left = root;

        if (root->Parent == nullptr)
        {
            root->colour = 0;
            return;
        }

        if (root->Parent->Parent == nullptr)
            return;

        INSERT(root);
    }

    void duplicate(T Vs)
    {
        if (DUPLICATE(RootRB, Vs) == true)
            cout << "\t" << " Value has been deleted from tree ";
        else
            cout << "Value not found ";

    }
    
    void MaxValue()
    {
        MAXVALUE(RootRB);
    }
    void MinValue()
    {
        MINVALUE(RootRB);
    }

    T GetRootNodes()
    {
        if (RootRB == nullptr)
        {
            cout << "Tree is empty ";
            return 0;
        }
        return this->RootRB->Data;
    }
    void destroytree()
    {
        if (RootRB == nullptr)
        {
            cout << "Tree is empty ";
            return;
        }
        delete RootRB;
        delete ParentRB;
        RootRB = nullptr;
        ParentRB = nullptr;
        cout << endl;
        cout << "Tree has been destroyed ";
        cout << endl;
        return;
    }
   
    void destroytreecomplete()
    {
        if (RootRB == nullptr)
        {
            cout << "Tree is empty ";
            return;
        }
        delete RootRB;
        delete ParentRB;
        RootRB = nullptr;
        ParentRB = nullptr;
        cout << endl;
        cout << "Tree has been destroyed completely ";
        cout << endl;
        return;
    }
    ~RedandBlackTree()
    {
        delete RootRB;
        delete ParentRB;
    }
};
