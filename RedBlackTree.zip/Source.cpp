#include<iostream>
#include<fstream>
#include"RedAndBlackTree.h"
using namespace std;

void menu()
{
	cout << "Press 1 to INSERT values in th tree : " << endl;
	cout << "Press 2 to DELETE values from the tree : " << endl;
	cout << "Press 3 for SEARCHING a value from the tree : " << endl;
	cout << "Press 4 for PRE-ORDER TRAVERSAL NLR : " << endl;
	cout << "Press 5 for IN-ORDER TRAVERSAL LNR : " << endl;
	cout << "Press 6 for POST-ORDER TRAVERSAL LRN : " << endl;
	cout << "Press 7 for PRE-ORDER TRAVERSAL NRL : " << endl;
	cout << "Press 8 for IN-ORDER TRAVERSAL RNL : " << endl;
	cout << "Press 9 for POST-ORDER TRAVERSAL RLN : " << endl;
	cout << "Press 10 to DESTROY the tree : " << endl;
	cout << "Press 12 for DISPLAYING parent node : " << endl;
	cout << "Press 13 to READ from filE : " << endl;
	cout << "Press 14 to DELETE all duplicates : " << endl;
	cout << "Press 15 to CREATE copy of tree : " << endl;
	cout << "Press 16 to DESTROY the complete tree : " << endl;
	cout << "Press 17 to EXIT : " << endl;

}
template<typename T>
void insertin(RedandBlackTree<int>& obj)
{
	int i;
	T j;
	cout << endl;
	cout << "\t" << "Press 1 to Enter value :";
	cout << endl;
	cout << "\t" << "Press 2 to stop :";
	cout << endl;
	cin >> i;
	if (i == 1)
	{
		cout << "Enter value to insert :";
		cin >> j;
		obj.insert(j);
		cout << endl;
		cout << "Value is inserted in the tree ";
		cout << endl;
		insertin<int>(obj);
	}
	else if (i == 2)
	{
		return;
	}
	if (i <= 0 || i > 2)
	{
		system("cls");
		cout << "Wrong input ";
		cout << endl;
		cout << "Enter again ";
		cout << endl;
		insertin<int>(obj);
	}
}


template<typename T>
void ReadFromFile(RedandBlackTree<T>& RBT)
{
	int i=0;
	int size=0;
	int loop = 0;
	ifstream fin("RedBlack.txt");
	if (!fin)
		cout << "file not found ";
	cout << endl;
	fin >> size;
	while (loop<size)
	{
		fin >> i;
		RBT.insert(i);
		loop++;
	}
	fin.close();
}
void call()
{
	int c;

	RedandBlackTree<int> RBT;
	int V = 0;
	while (1)
	{
		menu();
		cout << endl;
		cout << "\t" << "-> ENTER OPERATION YOU WANTED TO BE DONE <- : ";
		cin >> c;
		if (c <= 0)
		{
			cout << endl << "\t" << "Invalid Option : " << endl;
			cout << "Enter again : " << endl;
			call();
		}
		if (c > 17)
		{
			cout << endl << "\t" << "Invalid Option : " << endl;
			cout << "Enter again : " << endl;
			call();
		}
		switch (c)
		{
		case 1:
			system("cls");
			cout << "\t" << " >> Insert << ";
			insertin<int>(RBT);
			break;
		case 2:
			system("cls");
			cout << endl;
			cout << "\t" << ">> Enter the value to delete << : " << "\t";
			cin >> V;
			RBT.DeleteANode(V);
			cout << endl;
			break;

		case 3:
			system("cls");
			cout << endl;
			cout << "Enter Value to search : ";
			cin >> V;
			if (RBT.SearchvalueBool(V) == 1)
				cout << V<<" is found ";
			else
				cout << "Not found ";
			cout << endl;
			cout << endl;
			break;

		case 4:
			system("cls");
			cout << endl;
			cout << "\t" << " >> Pre Order << : " << endl;
			RBT.PreOrderNLR();
			cout << endl;
			break;
		case 5:
			system("cls");
			cout << endl;
			cout << "\t" << " >> In Order << : " << endl;
			RBT.InOrderLNR();
			cout << endl;
			break;
			
		case 6:
			system("cls");
			cout << endl;
			cout << "\t" << " >> Post Order << : " << endl;
			RBT.PostOrderLRN();
			cout << endl;
			break;
		case 7:
			system("cls");
			cout << endl;
			cout << "\t" << " >> Pre Order << : " << endl;
			RBT.PreOrderNRL();
			cout << endl;
		break;
		case 8:
			system("cls");
			cout << endl;
			cout << "\t" << " >> In Order << : " << endl;
			RBT.InOrderRNL();
			cout << endl;
			break;
		case 9:
			system("cls");
			cout << endl;
			cout << "\t" << " >> Post Order << : " << endl;
			RBT.PostOrderRLN();
			cout << endl;
			break;
		
		case 10:
			system("cls");
			cout << "\t" << " >> Destroy Tree << ";
			cout << endl;
			RBT.destroytree();
			cout << endl;
			cout << endl;
			break;
		case 12:
			system("cls");
			cout << endl;
			cout << "\t" << " >> Parent Node << : "<<"\t";
			cout<<RBT.GetRootNodes();
			cout << endl;
			break;

		case 13:
			system("cls");
			cout << "\t" << " >> Read from File << ";
			ReadFromFile<int>(RBT);
			cout << endl;
			cout << "\t" << " >> Data has bee entered in tree << ";
			cout << endl;
			cout << endl;
			break;
		case 14:
			system("Cls");
			cout << "\t" << " >> Delete Duplicate ";
			cout << endl;
			cout << "Enter Value to delete ";
			cin >> V;
			RBT.duplicate(V);
			cout << endl;
			break;
			
		case 15:
		{
			system("cls");
			cout <<"\t"<< " >> Create copy of Tree << ";
			cout << endl;
			RedandBlackTree<int> obj;
			obj.createcopy(RBT);
			break;
		}
		case 16:
			system("cls");
			cout << "\t" << " >> Destroy Tree << ";
			cout << endl;
			RBT.destroytreecomplete();
			cout << endl;
			cout << endl;
			break;
		case 17:
			system("cls");
			cout <<"\t" << " >> Program has been exited << ";
			exit(1);
			break;
		}
	}
}
int main()
{
	call();
   
  
}